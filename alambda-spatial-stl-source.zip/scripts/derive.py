import os,json,pathlib,math
import numpy as np
from scipy.spatial import cKDTree
from matplotlib.path import Path
ROOT=pathlib.Path(__file__).resolve().parents[1]
P=ROOT/'.cache'/'lidar'; pts=np.load(P/'full_points.npy'); md=json.load(open(P/'metadata.json'))
origin=[md['origin_lon'],md['origin_lat']];R=6378137;coslat=math.cos(math.radians(origin[1]))
ground=pts[pts[:,3]==2];tree=cKDTree(ground[:,:2]);axis=np.arange(-200,201,10);xx,yy=np.meshgrid(axis,axis);queries=np.column_stack((xx.ravel(),yy.ravel()));dist,inds=tree.query(queries,k=24);elev=np.median(ground[inds,2],axis=1)
grid={'cols':41,'rows':41,'step':10,'xmin':-200,'ymin':-200,'elevations':np.round(elev,3).tolist(),'method':'Median of 24 nearest classified ground returns at each 10m grid vertex; interpolated display surface, not raw measurements','max_neighbor_distance_m':float(dist[:,-1].max())}
(P/'terrain.json').write_text(json.dumps(grid,separators=(',',':')))
buildings=json.load(open(ROOT/'dist/data/buildings.geojson'))
res={}
for f in buildings['features']:
 rings=f['geometry']['coordinates'];poly=np.array(rings[0]); poly=np.column_stack(((poly[:,0]-origin[0])*math.pi/180*R*coslat,(poly[:,1]-origin[1])*math.pi/180*R));lo=poly.min(axis=0);hi=poly.max(axis=0);ctr=np.mean(poly[:-1],axis=0)
 _,gi=tree.query(ctr,k=64);base=float(np.median(ground[gi,2]));clip=bool(np.any(np.abs(poly)>200))
 m=(pts[:,0]>=lo[0])&(pts[:,0]<=hi[0])&(pts[:,1]>=lo[1])&(pts[:,1]<=hi[1]);local=pts[m];inside=Path(poly).contains_points(local[:,:2]);roof=local[inside];above=roof[(roof[:,2]>base+2)&(roof[:,3]!=2)]
 height=float(np.quantile(above[:,2],.95)-base) if len(above)>=20 and not clip else None
 res[str(f['properties']['OBJECTID'])]={'ground_m':round(base,3),'height_m':round(height,3) if height else None,'roof_p95_m':round(base+height,3) if height else None,'point_count':len(roof),'above_ground_point_count':len(above),'footprint_clipped':clip,'method':'2012 point-derived estimate (95th percentile of non-ground returns >2m above nearby ground inside city footprint); may include trees' if height else 'Insufficient unclipped point evidence; use explicitly estimated geometry'}
(P/'building-heights.json').write_text(json.dumps(res,separators=(',',':')))
md.update({'capture_start':'2012-01-29','capture_end':'2012-02-01','vertical_datum':'NAVD88 — Geoid03 (meters), as recorded in original source LAS metadata','original_horizontal_crs':'NAD83 / UTM zone 15N (EPSG:26915)','source_metadata_url':'https://usgs-lidar-public.s3.amazonaws.com/MO_StLouis_2012/ept-sources/MO_StLouis_2012_000042.json','usgs_metadata_url':'https://prd-tnm.s3.amazonaws.com/StagedProducts/Elevation/LPC/Projects/legacy/MO_STLOUIS_2012/metadata/USGS_LPC_MO_STLOUIS_2012_000042.xml','ground_median_m':float(np.median(ground[:,2])),'ground_min_m':float(ground[:,2].min()),'ground_max_m':float(ground[:,2].max()),'area_m2':160000,'full_return_density_per_m2':len(pts)/160000,'classification_labels':{'1':'Unclassified','2':'Ground','11':'Other returns (source class 11; semantics not verified)'},'source_classes':{'1':'Unclassified','2':'Ground','11':'Other returns (source class 11; semantics not verified)'},'notes':['Historical capture; buildings and vegetation may have changed since 2012.','Display point cloud is downsampled to 200,000 original returns.','Terrain is derived from classified ground points.','Solid building heights are point-derived estimates, not validated roof reconstructions or survey measurements.','Local XY uses a small-area equirectangular display approximation.','2017 dataset exists, but its current LAZ download host returned HTTP 429 during this extraction.']})
(P/'metadata.json').write_text(json.dumps(md,indent=2));print('saved',len(res),'buildings',sum(v['height_m'] is not None for v in res.values()),'point-derived heights','ground median',md['ground_median_m']);print('heights',list(res.items())[:3]);print('terrain',len(elev),min(elev),max(elev))

import shutil
for name in ['lidar.bin','classes.bin','metadata.json','terrain.json','building-heights.json']:
 shutil.copyfile(P/name,ROOT/'dist'/'data'/name)
