import urllib.request, urllib.parse, json, pathlib, datetime
from concurrent.futures import ThreadPoolExecutor
base='https://maps8.stlouis-mo.gov/arcgis/rest/services/ASSESSOR/Assessor_Public_Parcels/MapServer/'
out=pathlib.Path(__file__).resolve().parents[1]/'dist'/'data'
box=[-90.27425,38.66225,-90.26965,38.66595]
layers={'parcels':(11,'OBJECTID,ParcelId,LowAddrNum,StName,StType,SITEADDR,SQFT,VacantLot,Zoning,NbrOfBldgsRes,NbrOfBldgsCom,FirstYearBuilt,LastYearBuilt,AsdTotal,PriorAsdDate'),'buildings':(9,'OBJECTID,BLDGHEIGHT,EAVEHEIGHT,ROOFFORM,BASEELEV,ROOFDIR,SITEADDR,ParcelId,BuildingId,Const_Date,Demo_Date'),'streets':(5,'OBJECTID,StreetName,Street,StreetNamePostType,WidthMin,WidthMax,Vacated')}
def fetch(item):
 name,(layer,fields)=item
 p={'f':'geojson','where':'1=1','geometry':','.join(map(str,box)),'geometryType':'esriGeometryEnvelope','inSR':4326,'spatialRel':'esriSpatialRelIntersects','outFields':fields,'outSR':4326,'returnGeometry':'true','resultRecordCount':2000}
 url=base+str(layer)+'/query?'+urllib.parse.urlencode(p)
 d=json.load(urllib.request.urlopen(url,timeout=40))
 assert 'features' in d,d
 (out/(name+'.geojson')).write_text(json.dumps(d,separators=(',',':')))
 (out/(name+'-source.json')).write_text(json.dumps({'source':base+str(layer),'query':url,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'count':len(d['features']),'bounds':box}))
 print(name,len(d['features']),json.dumps(d['features'][:2])[:2200])
list(ThreadPoolExecutor().map(fetch,layers.items()))
