import sys,os,json,urllib.request,math,pathlib,concurrent.futures,time
import numpy as np, laspy
from pyproj import Transformer
P=pathlib.Path(__file__).resolve().parents[1]/'.cache'/'lidar'
P.mkdir(parents=True,exist_ok=True)
BASE='https://usgs-lidar-public.s3.amazonaws.com/MO_StLouis_2012/'
ORIGIN=(-90.27195,38.66410); R=6378137; coslat=math.cos(math.radians(ORIGIN[1]))
def fetch(s):
 p=P/s.replace('/','_');
 if p.exists():return p.read_bytes()
 b=urllib.request.urlopen(BASE+s,timeout=40).read();p.write_bytes(b);return b
meta=json.loads(fetch('ept.json'));bounds=meta['bounds'];w=bounds[3]-bounds[0]
cx,cy=Transformer.from_crs(4326,3857,always_xy=True).transform(*ORIGIN)
# Mercator scale conservative margin; clip precisely in local frame later.
aoi=(cx-205/coslat,cy-205/coslat,cx+205/coslat,cy+205/coslat)
def intersects(key):
 d,x,y,z=map(int,key.split('-'));size=w/(2**d);xmin=bounds[0]+x*size;ymin=bounds[1]+y*size
 return xmin<=aoi[2] and xmin+size>=aoi[0] and ymin<=aoi[3] and ymin+size>=aoi[1]
seen=set();nodes={};queue=['0-0-0-0']
while queue:
 keys=queue;queue=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
  vals=list(ex.map(lambda k:(k,json.loads(fetch('ept-hierarchy/'+k+'.json'))),keys))
 for k,v in vals:
  seen.add(k)
  for nk,n in v.items():
   if intersects(nk):
    if n<0 and nk not in seen:queue.append(nk)
    elif n>0:nodes[nk]=n
 print('hierarchy',len(seen),'nodes',len(nodes),'pending',len(queue),flush=True)
print('Downloading',len(nodes),'nodes',sum(nodes.values()),'unclipped points',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
 paths=list(ex.map(lambda k:(k,fetch('ept-data/'+k+'.laz')),nodes))
allparts=[];ll=Transformer.from_crs(3857,4326,always_xy=True)
for k,b in paths:
 import io
 pc=laspy.read(io.BytesIO(b));lon,lat=ll.transform(np.array(pc.x),np.array(pc.y));x=(lon-ORIGIN[0])*math.pi/180*R*coslat;y=(lat-ORIGIN[1])*math.pi/180*R
 z=np.array(pc.z);c=np.array(pc.classification);m=(np.abs(x)<=200)&(np.abs(y)<=200)&(c!=7)&(c!=18)
 if m.any():allparts.append(np.column_stack((x[m],y[m],z[m],c[m])))
pts=np.concatenate(allparts);np.save(P/'full_points.npy',pts)
print('CROPPED',pts.shape,'class counts',np.unique(pts[:,3],return_counts=True),flush=True)
# deterministic uniform sample of real points, no added measurements
rng=np.random.default_rng(20261113);idx=np.sort(rng.choice(len(pts),min(200000,len(pts)),replace=False));display=pts[idx]
display[:,:3].astype('<f4').tofile(P/'lidar.bin');display[:,3].astype('u1').tofile(P/'classes.bin')
md={'origin_lon':ORIGIN[0],'origin_lat':ORIGIN[1],'radius_m':200,'point_count':len(display),'full_point_count':len(pts),'z_min':float(pts[:,2].min()),'z_max':float(pts[:,2].max()),'class_counts':{str(int(k)):int(v) for k,v in zip(*np.unique(pts[:,3],return_counts=True))},'capture_year':2012,'source':'USGS 3DEP MO_StLouis_2012','source_url':BASE+'ept.json','horizontal_source_crs':'EPSG:3857','coordinate_frame':'x=east meters, y=north meters relative to origin, z=source elevation meters','local_formula':'x=(lon-origin_lon)*PI/180*6378137*cos(origin_lat*PI/180); y=(lat-origin_lat)*PI/180*6378137','sampling':'Deterministic random sample without replacement of original measured returns, excluding noise classes 7 and 18','classification_labels':{'1':'Unclassified','2':'Ground','3':'Low vegetation','4':'Medium vegetation','5':'High vegetation','6':'Building','7':'Noise','9':'Water'}}
(P/'metadata.json').write_text(json.dumps(md,indent=2))
