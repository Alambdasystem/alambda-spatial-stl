# Verification — November 13, 2026

Passed data checks: 200,000 XYZ records match 200,000 class records; terrain/elevation values finite; all five Ridge focus addresses exist; parsed city counts are 264 parcels and 150 footprints. JavaScript syntax and Python compilation pass.

Browser UI checked at desktop size and a 390 × 790 mobile viewport:

- Real 3D scene loads using Canvas compatibility rendering because this test browser disables WebGL.
- Search finds 5356 Ridge Ave and 5356 Wells Ave; unmatched text shows an explicit no-result message.
- Parcel selection shows expected ID, area, zoning, city building count, and spatially matched footprint count. Mixed-date discrepancies remain visible.
- Buildings, LiDAR, and Overlay modes switch; parcel and terrain toggles work.
- Fly-to, reset, top view, and orbit play/pause controls respond.
- Two ground clicks produce a horizontal measurement (observed test: 33.8 m / 111.0 ft).
- GeoJSON download parsed successfully: FeatureCollection, one Polygon, parcel ID 37999070000 for 5348 Ridge Ave.
- Data/source dialog presents historical capture, estimated geometry, fallback display count, and source links.
- Mobile drawer opens and selection closes it; no horizontal overflow (390px viewport and scroll width). Selected card is within the viewport (top 407.8, bottom 714 within height 790). Scene remains visible above it.

Limit: the WebGL rendering path cannot be visually exercised in this browser because GPU contexts are disabled. It uses the same checked scene geometry and standard Three.js materials; the compatibility path is the visually verified one. This is not a survey accuracy validation.
